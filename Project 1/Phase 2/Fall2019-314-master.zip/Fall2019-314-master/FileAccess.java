// This file gives access to the underlying datafile and stores the data in the Workout class.
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.math.BigInteger;
import java.util.Iterator;
import java.util.Scanner;

public class FileAccess {
  
  public static boolean loadPrimes(Primes primes, String filename) {
		return true;
  }
  
  public static boolean loadCrosses(Primes primes, String filename) {
    return true;
	}
  
  public static boolean savePrimes(Primes primes, String filename)
  {
  	return true;
  }
  
  public static boolean saveCrosses(Primes primes, String filename)
  {
  	return true;
  }
}