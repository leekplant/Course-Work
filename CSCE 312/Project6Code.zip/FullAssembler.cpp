//Samuel Tran
//CSCE 312-501
#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <string>
#include <unordered_map>
#include <bitset>
using namespace std;

unordered_map<string, string> typeC_comp ({{"0", "0101010"}, {"1", "0111111"}, {"-1", "0111010"}, {"D", "0001100"}, {"A", "0110000"}, {"M", "1110000"}, {"!D", "0001101"}, {"!A", "0110001"}, {"!M", "1110001"}, {"-D", "0001111"}, {"-A", "0110001"}, {"-M", "1110011"}, {"D+1", "0011111"}, {"A+1", "0110111"}, {"M+1", "1110111"}, {"D-1", "0001110"}, {"A-1", "0110010"}, {"M-1", "1110010"}, {"D+A", "0000010"}, {"A+D", "0000010"}, {"D+M", "1000010"}, {"M+D", "1000010"}, {"D-A", "0010011"}, {"D-M", "1010011"}, {"A-D", "0000111"}, {"M-D", "1000111"}, {"D&A", "0000000"}, {"D&M", "1000000"}, {"D|A", "0010101"}, {"D|M", "1010101"}});

unordered_map<string, string> typeC_dest ({{"null", "000"}, {"M", "001"}, {"D", "010"}, {"MD", "011"}, {"A", "100"}, {"AM", "101"}, {"AD", "110"}, {"AMD", "111"}});

unordered_map<string, string> typeC_jump ({{"null", "000"}, {"JGT", "001"}, {"JEQ", "010"}, {"JGE", "011"}, {"JLT", "100"}, {"JNE", "101"}, {"JLE", "110"}, {"JMP", "111"}});

unordered_map<string, int> typeA_symbols({{"R0", 0}, {"R1", 1}, {"R2", 2}, {"R3", 3}, {"R4", 4}, {"R5", 5}, {"R6", 6}, {"R7", 7}, {"R8", 8}, {"R9", 9}, {"R10", 10}, {"R11", 11}, {"R12", 12}, {"R13", 13}, {"R14", 14}, {"R15", 15}, {"SP", 0}, {"LCL", 1}, {"ARG", 2}, {"THIS", 3}, {"THAT", 4 }, {"SCREEN", 16384}, {"KBD", 24576 }});

int main() {
    string instLine;
    vector<string> instList;
    string dest, comp, jump;
    int iter = 16;
    int numOfLabels = 0;
    while(getline(cin, instLine, '\n')) {
        if(instLine.find("//") != std::string::npos) {
            instLine.erase(instLine.find("//"));
        }
        instLine.erase(std::remove(instLine.begin(), instLine.end(), ' '), instLine.end());
        instLine.erase(std::remove(instLine.begin(), instLine.end(), '\t'), instLine.end());
        if(isdigit(instLine[0]) || isalpha(instLine[0]) || instLine[0] == '@' || instLine[0] == '(') {
            if(instLine.at(instLine.length() - 1) == ';') {
                cout << "ERROR: end of line expected but semicolon is found";
                return 0;
            }
            instList.push_back(instLine);
        }
    }

    for(int x = 0; x < instList.size(); x++) {
        string tempLabel = instList.at(x);
        if(tempLabel[0] == '(') {
            string label = tempLabel.substr(1, tempLabel.length()-2);
            typeA_symbols.insert({label, x - numOfLabels});
            numOfLabels++;
        }
    }

    for(int i = 0; i < instList.size(); i++) {
        string inst = instList.at(i);

        for(int j = 0; j < inst.length(); j++) {
            if(inst[j] == '@') {
                string value = inst.substr(j+1, inst.length());
                if(typeA_symbols.find(value) != typeA_symbols.end()) {
                    cout << bitset<16>(typeA_symbols.at(value)).to_string() << endl;
                } else if(isdigit(value[0])) {
                    int digit = stoi(value);
                    cout << bitset<16>(digit).to_string() << endl;
                } else {
                    typeA_symbols[value] = iter++;
                    cout << bitset<16>(typeA_symbols.at(value)).to_string() << endl;
                }
            }
            if(inst[j] == '=') {
                dest = inst.substr(0, j);
                if(typeC_dest.find(dest) == typeC_dest.end()) {
                    cout << "ERROR: expression expected";
                    return 0;
                }
                string temp = inst.substr(j+1, inst.length());
                for(int k = 0; k < temp.length(); k++) {
                    if(temp[k] == ';') {
                        comp = temp.substr(0, k);
                        jump = temp.substr(k+1, temp.length());
                        if(typeC_comp.find(comp) == typeC_comp.end()) {
                            cout << "ERROR: expression expected";
                            return 0;
                        }
                        if(typeC_jump.find(jump) == typeC_jump.end()) {
                            cout << "ERROR: expression expected";
                            return 0;
                        }
                        cout << "111" << typeC_comp.at(comp);
                        cout << typeC_dest.at(dest);
                        cout << typeC_jump.at(jump) << endl;
                    }
                }
                if(inst.find(';') == std::string::npos) {
                    comp = temp;
                    if(typeC_comp.find(comp) == typeC_comp.end()) {
                        cout << "ERROR: expression expected";
                        return 0;
                    }
                    cout << "111" << typeC_comp.at(comp);
                    cout << typeC_dest.at(dest);
                    cout << typeC_jump.at("null") << endl;
                }
            }
            if(inst[j] == ';') {
                if(inst.find('=') == std::string::npos) {
                    comp = inst.substr(0, j);
                    jump = inst.substr(j+1, inst.length());
                    if(typeC_comp.find(comp) == typeC_comp.end()) {
                        cout << "ERROR: expression expected";
                        return 0;
                    }
                    if(typeC_jump.find(jump) == typeC_jump.end()) {
                        cout << "ERROR: expression expected";
                        return 0;
                    }
                    cout << "111" << typeC_comp.at(comp);
                    cout << typeC_dest.at("null");
                    cout << typeC_jump.at(jump) << endl;
                }
            }
        }
    }

    return 0;
}
