#include <cmath>
#include <cstdio>
#include <vector>
#include <iostream>
#include <sstream>
#include <algorithm>
#include <string>
#include <unordered_map>
#include <bitset>
using namespace std;

unordered_map<string, string> typeC_comp ({{"0", "0101010"}, {"1", "0111111"}, {"-1", "0111010"}, {"D", "0001100"}, {"A", "0110000"}, {"M", "1110000"}, {"!D", "0001101"}, {"!A", "0110001"}, {"!M", "1110001"}, {"-D", "0001111"}, {"-A", "0110001"}, {"-M", "1110011"}, {"D+1", "0011111"}, {"A+1", "0110111"}, {"M+1", "1110111"}, {"D-1", "0001110"}, {"A-1", "0110010"}, {"M-1", "1110010"}, {"D+A", "0000010"}, {"D+M", "1000010"}, {"D-A", "0010011"}, {"D-M", "1010011"}, {"A-D", "0000111"}, {"M-D", "1000111"}, {"D&A", "0000000"}, {"D&M", "1000000"}, {"D|A", "0010101"}, {"D|M", "1010101"}});

unordered_map<string, string> typeC_dest ({{"null", "000"}, {"M", "001"}, {"D", "010"}, {"MD", "011"}, {"A", "100"}, {"AM", "101"}, {"AD", "110"}, {"AMD", "111"}});

unordered_map<string, string> typeC_jump ({{"null", "000"}, {"JGT", "001"}, {"JEQ", "010"}, {"JGE", "011"}, {"JLT", "100"}, {"JNE", "101"}, {"JLE", "110"}, {"JMP", "111"}});


int main() {
    string instLine;
    vector<string> instList;
    string dest, comp, jump;

    while(getline(cin, instLine, '\n')) {
        if(instLine.find("//") != std::string::npos) {
            instLine.erase(instLine.find("//"));
        }
        instList.push_back(instLine);
    }
    for(int i = 0; i < instList.size(); i++) {
        string inst = instList.at(i);
        inst.erase(std::remove(inst.begin(), inst.end(), ' '), inst.end());
        inst.erase(std::remove(inst.begin(), inst.end(), '\t'), inst.end());
        for(int j = 0; j < inst.length(); j++) {
            if(inst[j] == '@') {
                string digit = inst.substr(j+1, inst.length());
                int value = stoi(digit);
                cout << bitset<16>(value).to_string() << endl;
            }
            if(inst[j] == '=') {
                dest = inst.substr(0, j);
                string temp = inst.substr(j+1, inst.length());
                for(int k = 0; k < temp.length(); k++) {
                    if(temp[k] == ';') {
                        comp = temp.substr(0, k);
                        jump = temp.substr(k+1, temp.length());
                        cout << "111" << typeC_comp.at(comp);
                        cout << typeC_dest.at(dest);
                        cout << typeC_jump.at(jump) << endl;
                    }
                }
                if(inst.find(';') == std::string::npos) {
                    comp = temp;
                    cout << "111" << typeC_comp.at(comp);
                    cout << typeC_dest.at(dest);
                    cout << typeC_jump.at("null") << endl;
                }
            }
            if(inst[j] == ';') {
                if(inst.find('=') == std::string::npos) {
                    comp = inst.substr(0, j);
                    jump = inst.substr(j+1, inst.length());
                    cout << "111" << typeC_comp.at(comp);
                    cout << typeC_dest.at("null");
                    cout << typeC_jump.at(jump) << endl;
                }
            }
        }
    }


    return 0;
}
